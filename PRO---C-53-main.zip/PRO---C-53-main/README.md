# PRO---C-53
Let's Get Started Coder!!
Fill the following Document
__________________________________________________________________________

1. Which one of the following is an Imperative Language??

1.	HTML
2.	CSS
3.	Java Script

Answer: Java Script	


2. Which one of the following is a Declarative Language??

1.	HTML
2.	CSS
3.	Java Script

Answer: HTML


3. Name two uses of a DIV tag??

Answer:
The div tag is used in HTML to make divisions of content in the web page like (text, images, header, footer, navigation bar, etc). Div tag has both open(<div>) and closing (</div>) tag and it is mandatory to close the tag.







4. What is the difference between relative positioning and absolute positioning in HTML?

Answer: Relative - the element is positioned relative to its normal position. Absolute - the element is positioned absolutely to its first positioned parent




5. What is the use of opacity in CSS??

Answer: The opacity property in CSS specifies how transparent an element is. Opacity has a default initial value of 1 (100% opaque). Opacity is not inherited, but because the parent has opacity that applies to everything within it.





6. Which is the programming language used in the React Native Framework??

Answer: 
For React Native, for the programming language - you need JavaScript or a slightly different take on JavaScript which mixes JavaScript and HTML type syntax called JSX.


7. Which online editor are we using for creating our apps in React Native Framework??

Answer: 
Expo online editor




8. Write the steps to test your first designed app in the online editor on a mobile.

Answer:
1.	Download expo app from playstore
2.	Open it
3.	Sign up with expo on your pc
4.	Make a project
5.	Click connect your device 
6.	On mobile click scan QR code
7.	Scan it







9. What is the use of the render function in React Native Framework??

Answer: 
The term “render prop” refers to a technique for sharing code between React components using a prop whose value is a function. A component with a render prop takes a function that returns a React element and calls it instead of implementing its own render logic.






10. What is the use of return function  in React Native Framework??

Answer:
Whatever a function component returns is rendered as a React element. React elements let you describe what you want to see on the screen.






11. What are the various components in your first app that you designed??

Answer: 
Render 
View 
Button
Return



